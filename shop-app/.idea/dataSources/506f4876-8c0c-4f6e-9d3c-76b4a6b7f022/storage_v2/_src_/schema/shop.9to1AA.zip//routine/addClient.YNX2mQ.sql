create
    definer = root@localhost procedure addClient(IN n varchar(50), IN s varchar(50), IN a varchar(100))
begin
 if exists (select name, surname, address from Clients where name=n and surname=s and address=a) then
	 signal sqlstate '45000' set message_text="Client already exists";
 else
	insert into Clients(name,surname,address)
	values (n,s,a);
 end if;
end;

