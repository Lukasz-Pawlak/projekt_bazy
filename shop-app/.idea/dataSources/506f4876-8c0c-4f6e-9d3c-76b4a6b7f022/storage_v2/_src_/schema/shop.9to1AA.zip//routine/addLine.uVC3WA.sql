create
    definer = root@localhost procedure addLine(IN inv int, IN prod int, IN units int)
begin
    DECLARE t DECIMAL(5,2);
    DECLARE c DECIMAL(5,2);
    SET @t=(SELECT pricePerUnit FROM offer WHERE product=prod)*units;
    INSERT INTO invoiceline (totalPrice,units,product,invoice)
    VALUES (@t,units,prod,inv); /* cenę za wszystkie sztuki wstawiamy tutaj czy robimy triggera?*/

end;

