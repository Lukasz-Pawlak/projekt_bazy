create
    definer = root@localhost procedure addProduct(IN c varchar(30), IN b varchar(30), IN cLn varchar(30), IN cLv int,
                                                  IN t varchar(20), IN n varchar(100), IN price decimal(5, 2),
                                                  IN units int)
begin
declare ci, bi, cLi, ti, pom int;
	if c not in (select name from Colors) then
        insert into colors (name) values (c);
    end if;
    if b not in (select name from Brands) then
        insert into brands (name) values (b);
    end if;
    if not exists (select * from CoverageLevels where name = cLn and numericValue = cLv) then
        insert into coveragelevels (numericValue, name) values (cLv, cLn);
    end if;
    if t not in (select name from types) then
        insert into types (name) values (t);
    end if;
    select id from types where name = t into ti;
    select id from coveragelevels where name = cLn and numericValue = cLv into cLi;
    select id from brands where name = b into bi;
    select id from colors where name = c into ci;
    if exists (
        select * from products
        where color = ci
        and coverageLevel = cLi
        and brand = bi
        and type = ti
    ) then
    signal sqlstate '45000' set message_text="This product already exists";
    else
	    insert into Products (color,brand,coverageLevel,TYPE,name)
        values(ci, bi, cLi, ti,n);
        SELECT id FROM products WHERE color=ci AND brand=bi AND coverageLevel=cLi AND TYPE=ti INTO pom;
        INSERT INTO offer(pricePerUnit,unitsInStock,product)
        VALUES(price,units,pom);
	end if;
end;

