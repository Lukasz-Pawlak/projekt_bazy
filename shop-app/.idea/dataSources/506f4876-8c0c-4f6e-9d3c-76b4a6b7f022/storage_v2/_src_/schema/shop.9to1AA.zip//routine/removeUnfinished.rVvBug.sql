create
    definer = root@localhost procedure removeUnfinished(IN id_in int)
BEGIN
    DELETE FROM invoiceLine
    WHERE invoice = id_in;
    DELETE FROM invoices
    WHERE id = id_in;
END;

