create
    definer = root@localhost function addInvoice(cl int) returns int
begin
    declare date DATETIME;
    declare result int;
    SET @date=now();
    insert into invoices (dateIssued,CLIENT,confirmed)
    VALUES (@date,cl,false);
    SET @result=(select id from invoices where client=cl and dateIssued=@date);
    RETURN @result;
end;

