create
    definer = root@localhost procedure addInvoice(IN cl int, OUT fv int)
begin
    declare date DATETIME;
    declare result int;
    SET @date=now();
    insert into invoices (dateIssued,CLIENT,confirmed)
    VALUES (@date,cl,false);
    SET @result=(select id from invoices where client=cl and dateIssued=@date);
    SELECT @result INTO fv;
end;

